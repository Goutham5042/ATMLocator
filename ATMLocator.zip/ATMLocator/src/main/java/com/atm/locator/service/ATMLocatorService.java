package com.atm.locator.service;

import java.util.List;

import com.atm.locator.model.ATMDetails;


public interface ATMLocatorService {
	
	List<ATMDetails> getAllAtms();
	List<ATMDetails> getAtmByCity(String city);

}

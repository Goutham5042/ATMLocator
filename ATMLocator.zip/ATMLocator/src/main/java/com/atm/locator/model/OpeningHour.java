package com.atm.locator.model;

import java.util.List;

public class OpeningHour {
	
	private String dayOfWeek;
	
	private List<Hour> hours;

	public String getDayOfWeek() {
		return dayOfWeek;
	}

	public void setDayOfWeek(String dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
	}

	public List<Hour> getHours() {
		return hours;
	}

	public void setHours(List<Hour> hours) {
		this.hours = hours;
	}

	
}

package com.atm.locator.service.impl;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.atm.locator.controllers.ATMLocatorController;
import com.atm.locator.model.ATMDetails;
import com.atm.locator.service.ATMLocatorService;

@Service
public class ATMLocatorServiceImpl implements ATMLocatorService {
	
	@Autowired
	RestTemplate restTemplate;
	
	@Value("${atm.locator.external.service.endpoint}")
	private String endPoint;
	
	Logger log = LoggerFactory.getLogger(ATMLocatorServiceImpl.class);
	
	
	public List<ATMDetails> getAllAtms()
	{
		log.info("getAllAtms started");
		List<ATMDetails> atmList = callATMLocatorService();
		log.info("getAllAtms ended");
		return atmList;
		
	}
	
	public List<ATMDetails> getAtmByCity(String city)
	{
		log.info("getAtmByCity started");
		List<ATMDetails> atmList = callATMLocatorService();
		//Filtering ATMS based on city
		List<ATMDetails> filteredResponse = atmList.stream()
                .filter(a -> city.equals(a.getAddress().getCity()))
                .collect(Collectors.toList());
		log.info("getAtmByCity ended");
		return filteredResponse;
		
	}
	
	public List<ATMDetails> callATMLocatorService()
	{
		log.info("Creating request entity to call ATM Locator external service");
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		
		HttpEntity<String> entity = new HttpEntity<String>(null,httpHeaders);
		log.info("Calling ATM Locator external service ");
		ATMDetails[] serviceResponse = restTemplate.exchange(endPoint,HttpMethod.GET,entity,ATMDetails[].class).getBody();
		log.info("Response received from ATM Locator external service is {} ",serviceResponse.toString());
		List<ATMDetails> atmList = Arrays.asList(serviceResponse);
		return atmList;
	}

	

}

package com.atm.locator;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT,classes=ATMLocatorApplication.class)
class ATMLocatorApplicationTest {


	@LocalServerPort
	int localPort;

	@Autowired
	TestRestTemplate testRestTemplate;
	   
	   @Test
	   public void getATMListMocking() throws Exception {
		   ResponseEntity responseEntity = testRestTemplate.getForEntity("http://localhost:"+localPort+"/locator/api/atms", List.class);
		   System.out.println(responseEntity.getBody());
		   }
	   
	   
	   @Test
	   public void getATMDetailsByCityMocking() throws Exception {
		   String city="Gieten";
		   ResponseEntity responseEntity = testRestTemplate.getForEntity("http://localhost:"+localPort+"/locator/api/atms/getByCity?city="+city, List
				   .class);
		   System.out.println(responseEntity.getBody());
		   }

}
